<script setup lang="ts">
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { CircleAlert, Loader2 } from 'lucide-vue-next';
import { computed } from 'vue';
import InputError from '../InputError.vue';

const props = defineProps<{
    inputType: 'id' | 'id+server';
    labelId: string;
    labelServer: string;
    serverOptions: (string | { label: string; value: string })[];
    accountId: string;
    serverId: string;
    formErrors: any;
    resolvedUsername?: string | null;
    checkError?: string | null;
    isLoadingCheck?: boolean;
}>();

const emit = defineEmits<{
    'update:accountId': [value: string];
    'update:serverId': [value: string];
}>();

const hasServerDropdown = computed(
    () => props.inputType === 'id+server' && props.serverOptions.length > 0,
);
</script>

<template>
    <section class="rounded-lg border border-border/50 bg-card p-6 shadow-sm">
        <h2
            class="mb-4 flex items-center gap-2 text-lg font-bold text-foreground"
        >
            <span
                class="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground"
                >1</span
            >
            Masukkan Data Akun
        </h2>

        <p
            class="mb-6 flex items-center gap-2 rounded-md bg-secondary p-3 text-sm text-muted-foreground"
        >
            <CircleAlert class="h-4 w-4 flex-shrink-0 text-destructive" />
            Pastikan data akun yang kamu masukkan benar.
        </p>

        <div
            class="grid gap-4"
            :class="inputType === 'id+server' ? 'sm:grid-cols-2' : ''"
        >
            <!-- ID Input -->
            <div>
                <Label :for="'account-id'">{{ labelId }}</Label>
                <Input
                    id="account-id"
                    :model-value="accountId"
                    :placeholder="`Masukkan ${labelId}`"
                    class="mt-1"
                    :disabled="isLoadingCheck"
                    @update:model-value="
                        emit('update:accountId', String($event))
                    "
                />
                <InputError :message="formErrors.account_id" class="mt-1" />
            </div>

            <!-- Server Input/Dropdown (conditional) -->
            <div v-if="inputType === 'id+server'">
                <Label :for="'server-id'">{{ labelServer }}</Label>

                <!-- Dropdown if servers available -->
                <Select
                    v-if="hasServerDropdown"
                    :model-value="serverId"
                    @update:model-value="
                        emit('update:serverId', String($event))
                    "
                >
                    <SelectTrigger
                        id="server-id"
                        class="mt-1"
                        :disabled="isLoadingCheck"
                    >
                        <SelectValue :placeholder="`Pilih ${labelServer}`" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem
                            v-for="server in serverOptions"
                            :key="
                                typeof server === 'string'
                                    ? server
                                    : server.value
                            "
                            :value="
                                typeof server === 'string'
                                    ? server
                                    : server.value
                            "
                        >
                            {{
                                typeof server === 'string'
                                    ? server
                                    : server.label
                            }}
                        </SelectItem>
                    </SelectContent>
                </Select>

                <!-- Text input if no servers -->
                <Input
                    v-else
                    id="server-id"
                    :disabled="isLoadingCheck"
                    :model-value="serverId"
                    :placeholder="`Masukkan ${labelServer}`"
                    class="mt-1"
                    @update:model-value="
                        emit('update:serverId', String($event))
                    "
                />
                <InputError :message="formErrors.server_id" class="mt-1" />
            </div>
        </div>

        <div
            v-if="isLoadingCheck || resolvedUsername || checkError"
            class="mt-4 flex items-center gap-2 rounded-lg border bg-muted/50 p-3 text-sm"
        >
            <Loader2
                v-if="isLoadingCheck"
                class="h-4 w-4 animate-spin text-muted-foreground"
            />
            <div v-if="resolvedUsername" class="font-medium text-green-600">
                Username: {{ resolvedUsername }}
            </div>
            <div v-else-if="checkError" class="font-medium text-destructive">
                {{ checkError }}
            </div>
            <div v-else-if="isLoadingCheck" class="text-muted-foreground">
                Mengecek ID...
            </div>
        </div>
    </section>
</template>
